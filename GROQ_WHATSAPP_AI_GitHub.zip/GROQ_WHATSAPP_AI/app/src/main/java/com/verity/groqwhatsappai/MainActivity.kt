package com.verity.groqwhatsappai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var keyInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 28)
            setBackgroundColor(0xFF101820.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 24)
        }
        fun text(value: String, size: Float = 16f, color: Int = 0xFFFFFFFF.toInt()) =
            TextView(this).apply { this.text = value; textSize = size; setTextColor(color); setPadding(0, 12, 0, 12) }

        content.addView(text("GROQ WHATSAPP AI", 26f, 0xFF62D6A4.toInt()))
        content.addView(text("Asistente personal para WhatsApp", 15f, 0xFFB8C4CC.toInt()))
        status = text("Estado: configura tu API Key y activa el acceso a notificaciones.", 14f, 0xFFFFD166.toInt())
        content.addView(status)

        content.addView(text("Groq API Key", 17f))
        keyInput = EditText(this).apply {
            hint = "Pega aquí tu API Key"
            setSingleLine(true)
            inputType =  visiblePasswordType()
            setText(SecureStore.apiKey(this@MainActivity))
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF9AA7B2.toInt())
        }
        content.addView(keyInput, LinearLayout.LayoutParams(-1, -2))

        content.addView(Button(this).apply {
            text = "Guardar API Key de forma privada"
            setOnClickListener {
                val key = keyInput.text.toString().trim()
                if (!key.startsWith("gsk_") || key.length < 20) {
                    status.text = "Revisa la clave. Las claves de Groq suelen comenzar con gsk_."
                } else {
                    SecureStore.saveApiKey(this@MainActivity, key)
                    keyInput.setText("")
                    status.text = "API Key guardada en almacenamiento cifrado."
                }
            }
        })
        content.addView(Button(this).apply {
            text = "Activar acceso a notificaciones"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        })
        content.addView(Button(this).apply {
            text = "Permitir notificaciones de esta app"
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= 33) {
                    ActivityCompat.requestPermissions(this@MainActivity, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 20)
                }
            }
        })
        content.addView(Button(this).apply {
            text = "Ver permisos guardados"
            setOnClickListener {
                val count = SecureStore.allPermissions(this@MainActivity).size
                status.text = "Contactos con una decisión guardada: $count. Para cambiar permisos, borra los datos de la app en Ajustes."
            }
        })
        content.addView(text("Cómo funciona", 19f, 0xFF62D6A4.toInt()))
        content.addView(text(
            "1. Guarda tu API Key.\n" +
            "2. Activa el acceso a notificaciones en Android.\n" +
            "3. Permite las notificaciones de GROQ WHATSAPP AI.\n" +
            "4. Cuando llegue un mensaje, aparecerá una solicitud con tres opciones.\n\n" +
            "Permitir siempre autoriza automáticamente a ese contacto. No permitir bloquea las respuestas automáticas para ese contacto.",
            14f, 0xFFD5DEE5.toInt()
        ))
        content.addView(text("Privacidad: el texto del mensaje se envía a Groq solo después de que autorices la respuesta. La API Key no se incluye en GitHub.", 13f, 0xFFB8C4CC.toInt()))
        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 20)
        }
    }

    private fun visiblePasswordType(): Int = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
}
