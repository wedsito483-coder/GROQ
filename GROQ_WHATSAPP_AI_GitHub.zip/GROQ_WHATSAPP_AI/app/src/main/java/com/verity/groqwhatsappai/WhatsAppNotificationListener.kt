package com.verity.groqwhatsappai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat
import java.util.concurrent.ConcurrentHashMap

class WhatsAppNotificationListener : NotificationListenerService() {
    companion object {
        const val CHANNEL = "groq_approval"
        const val PACKAGE_WHATSAPP = "com.whatsapp"
        val pendingReplies = ConcurrentHashMap<Int, ReplyTarget>()

        data class ReplyTarget(
            val contact: String,
            val message: String,
            val action: Notification.Action
        )
    }

    override fun onCreate() {
        super.onCreate()
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel(CHANNEL, "Solicitudes de Groq", NotificationManager.IMPORTANCE_HIGH))
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != PACKAGE_WHATSAPP) return
        val notification = sbn.notification ?: return
        val extras = notification.extras ?: return
        val contact = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val message = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString()?.trim().orEmpty()
        if (contact.isBlank() || message.isBlank() || message == " " || contact == "WhatsApp") return

        val replyAction = notification.actions?.firstOrNull { action ->
            val inputs = action.remoteInputs
            !inputs.isNullOrEmpty() && inputs.any { it.allowFreeFormInput }
        } ?: return

        val saved = SecureStore.permission(this, contact)
        val id = (sbn.key.hashCode() and 0x7fffffff)
        pendingReplies[id] = ReplyTarget(contact, message, replyAction)

        when (saved) {
            "always" -> ApprovalReceiver.handle(this, id, "always")
            "deny" -> pendingReplies.remove(id)
            else -> postApproval(id, contact, message)
        }
    }

    private fun postApproval(id: Int, contact: String, message: String) {
        val manager = getSystemService(NotificationManager::class.java)
        fun action(label: String, mode: String, request: Int): NotificationCompat.Action {
            val intent = Intent(this, ApprovalReceiver::class.java).apply {
                putExtra("reply_id", id)
                putExtra("mode", mode)
            }
            val pending = PendingIntent.getBroadcast(this, request, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            return NotificationCompat.Action.Builder(0, label, pending).build()
        }
        val notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_email)
            .setContentTitle("¿Autorizar respuesta a $contact?")
            .setContentText(message.take(120))
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .addAction(action("Permitir esta vez", "once", id * 3 + 1))
            .addAction(action("Permitir siempre", "always", id * 3 + 2))
            .addAction(action("No permitir", "deny", id * 3 + 3))
            .build()
        manager.notify(id, notification)
    }
}
