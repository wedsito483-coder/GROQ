# GROQ WHATSAPP AI

Proyecto inicial Android (Kotlin) para responder mensajes de WhatsApp personal mediante notificaciones y Groq.

## Importante: estado del proyecto

Este ZIP es un **prototipo inicial**, no una aplicación probada ni una APK lista para instalar. La respuesta automática depende de que WhatsApp publique una acción de respuesta rápida compatible en la notificación. Algunos tipos de mensajes, notificaciones agrupadas, mensajes multimedia o configuraciones del fabricante pueden no exponer esa acción.

La API Key se guarda con AndroidX EncryptedSharedPreferences. No pegues la clave en el código ni la subas a GitHub.

## Compilar con GitHub Actions

1. Crea un repositorio nuevo en GitHub.
2. Sube el contenido de este ZIP a la raíz del repositorio.
3. Abre la pestaña **Actions** y habilita los workflows si GitHub lo solicita.
4. Ejecuta **Build Android APK** o haz un push a `main`.
5. Cuando termine, abre la ejecución y descarga el artefacto `GROQ-WHATSAPP-AI-debug`.
6. Extrae el APK del artefacto e instálalo en Android.

## Configuración en Android

1. Abre GROQ WHATSAPP AI.
2. Pega tu API Key de Groq y guárdala.
3. Pulsa **Activar acceso a notificaciones** y habilita el servicio.
4. Permite las notificaciones de GROQ WHATSAPP AI.
5. Mantén WhatsApp con las notificaciones activadas.

## Permisos

- **Permitir esta vez:** responde al mensaje pendiente.
- **Permitir siempre:** guarda autorización para ese contacto.
- **No permitir:** guarda el bloqueo para ese contacto.

En este prototipo, para restablecer permisos guardados puedes borrar los datos de la aplicación desde Ajustes de Android.

## Modelo Groq

El modelo inicial configurado es `llama-3.3-70b-versatile`. Si Groq deja de ofrecerlo o lo cambia, actualiza el campo `model` en `GroqClient.kt` por un modelo vigente disponible en tu cuenta.

## Limitaciones y privacidad

- La aplicación lee el contenido de notificaciones de WhatsApp mediante el permiso especial de Android.
- Solo envía el texto a Groq cuando se autoriza una respuesta o existe permiso permanente.
- La API Key y las decisiones de autorización se guardan localmente cifradas.
- No se leen chats antiguos ni se accede a la base de datos privada de WhatsApp.
- No hay garantía de respuesta para notificaciones sin una acción de respuesta rápida.
- Para producción faltan pruebas en dispositivos reales, gestión visible de contactos bloqueados/autorizados, manejo de errores en pantalla, deduplicación avanzada y revisión de compatibilidad con versiones actuales de Android/WhatsApp.
