package com.verity.groqwhatsappai

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object GroqClient {
    fun answer(apiKey: String, message: String): String {
        val connection = (URL("https://api.groq.com/openai/v1/chat/completions").openConnection() as HttpURLConnection)
        connection.requestMethod = "POST"
        connection.connectTimeout = 15000
        connection.readTimeout = 30000
        connection.doOutput = true
        connection.setRequestProperty("Authorization", "Bearer $apiKey")
        connection.setRequestProperty("Content-Type", "application/json")

        val body = JSONObject().apply {
            put("model", "llama-3.3-70b-versatile")
            put("temperature", 0.4)
            put("max_tokens", 180)
            put("messages", JSONArray().put(JSONObject().apply {
                put("role", "system")
                put("content", "Eres un asistente de WhatsApp. Responde en español, de forma breve, clara y natural. No inventes datos.")
            }).put(JSONObject().apply {
                put("role", "user")
                put("content", message)
            }))
        }

        try {
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) {
                val detail = try { JSONObject(response).optJSONObject("error")?.optString("message") } catch (_: Exception) { null }
                throw IllegalStateException("Groq respondió HTTP $code: ${detail ?: response.take(250)}")
            }
            return JSONObject(response).getJSONArray("choices")
                .getJSONObject(0).getJSONObject("message").getString("content").trim()
        } finally {
            connection.disconnect()
        }
    }
}
