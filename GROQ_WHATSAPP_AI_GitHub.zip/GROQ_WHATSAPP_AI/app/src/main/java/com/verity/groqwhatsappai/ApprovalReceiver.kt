package com.verity.groqwhatsappai

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.app.RemoteInput
import android.os.Bundle
import java.util.concurrent.Executors

class ApprovalReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra("reply_id", -1)
        val mode = intent.getStringExtra("mode") ?: "deny"
        handle(context, id, mode)
    }

    companion object {
        private val executor = Executors.newSingleThreadExecutor()

        fun handle(context: Context, id: Int, mode: String) {
            val target = WhatsAppNotificationListener.pendingReplies[id] ?: return
            if (mode == "deny") {
                SecureStore.setPermission(context, target.contact, "deny")
                WhatsAppNotificationListener.pendingReplies.remove(id)
                return
            }
            if (mode == "always") SecureStore.setPermission(context, target.contact, "always")

            val apiKey = SecureStore.apiKey(context)
            if (apiKey.isBlank()) {
                WhatsAppNotificationListener.pendingReplies.remove(id)
                return
            }

            executor.execute {
                try {
                    val response = GroqClient.answer(apiKey, target.message)
                    val action = target.action
                    val remoteInputs = action.remoteInputs ?: emptyArray()
                    if (remoteInputs.isEmpty()) return@execute
                    val input = remoteInputs.firstOrNull { it.allowFreeFormInput } ?: remoteInputs[0]
                    val fillIn = Intent()
                    val results = Bundle().apply { putCharSequence(input.resultKey, response) }
                    RemoteInput.addResultsToIntent(remoteInputs, fillIn, results)
                    action.actionIntent.send(context, 0, fillIn)
                } catch (_: Exception) {
                    // No se envía nada si Groq falla. El usuario puede revisar la conexión y los límites de API.
                } finally {
                    WhatsAppNotificationListener.pendingReplies.remove(id)
                    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
                    manager.cancel(id)
                }
            }
        }
    }
}
