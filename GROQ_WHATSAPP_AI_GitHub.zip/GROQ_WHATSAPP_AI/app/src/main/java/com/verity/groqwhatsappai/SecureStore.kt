package com.verity.groqwhatsappai

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

object SecureStore {
    private fun prefs(context: Context) =
        EncryptedSharedPreferences.create(
            context,
            "groq_secure_settings",
            MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )

    fun apiKey(context: Context): String = prefs(context).getString("api_key", "") ?: ""
    fun saveApiKey(context: Context, key: String) { prefs(context).edit().putString("api_key", key.trim()).apply() }

    fun permission(context: Context, contact: String): String =
        prefs(context).getString("contact_${contactKey(contact)}", "") ?: ""

    fun setPermission(context: Context, contact: String, value: String) {
        prefs(context).edit().putString("contact_${contactKey(contact)}", value).apply()
    }

    fun allPermissions(context: Context): Map<String, *> = prefs(context).all.filterKeys { it.startsWith("contact_") }

    private fun contactKey(contact: String) =
        java.security.MessageDigest.getInstance("SHA-256")
            .digest(contact.trim().lowercase().toByteArray())
            .joinToString("") { "%02x".format(it) }
}
